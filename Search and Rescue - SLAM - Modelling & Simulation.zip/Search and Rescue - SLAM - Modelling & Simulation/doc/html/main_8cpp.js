var main_8cpp =
[
    [ "broadcast", "main_8cpp.html#a299d89c50484c4d3a597f6b43b65e21c", null ],
    [ "fiducial_callback", "main_8cpp.html#aef65d976146cab1c9987f30e9c49c6f8", null ],
    [ "listen", "main_8cpp.html#a1cb8c936ae579242b9f9fe4f9d172e73", null ],
    [ "main", "main_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ]
];