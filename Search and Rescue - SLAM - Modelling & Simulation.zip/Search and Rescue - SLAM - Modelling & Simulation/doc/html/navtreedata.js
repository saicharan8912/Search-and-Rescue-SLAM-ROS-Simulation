var NAVTREE =
[
  [ "My Project", "index.html", [
    [ "final_project", "md__home_ashutosh_catkin_ws_src_final_project__r_e_a_d_m_e.html", null ],
    [ "text", "md__home_ashutosh_catkin_ws_src_final_project_text.html", null ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';